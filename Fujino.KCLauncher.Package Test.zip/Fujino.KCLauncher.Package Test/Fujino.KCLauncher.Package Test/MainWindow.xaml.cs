﻿using FujinoNs;
using System.Windows;

namespace Fujino.KCLauncher.Package_Test
{
    public partial class MainWindow : Window
    {
        // Please Restore NuGet Packages!
        // โปรด Restore NuGet Packages!

        public MainWindow()
        {
            InitializeComponent();
            this.CheckInternet();
            this.SteamInfo();
        }

        void CheckInternet()
        {
            if (KCInternet.CheckInternet() == true)
            {
                lbl_internet.Content = "Internet Online";
            }
            else
            {
                lbl_internet.Content = "Internet Offline";
            }
        }


        KCSteamInfo _steamInfo = new KCSteamInfo();
        void SteamInfo()
        {
            lbl_steamname.Content = _steamInfo.SteamName();
            lbl_steamid.Content = _steamInfo.SteamID();
        }

        KCConnect _connect = new KCConnect();
        private void btn_joingame_Click(object sender, RoutedEventArgs e)
        {
            _connect.Server("127.0.0.1:30120");
        }

        private void btn_joingameJoinID_Click(object sender, RoutedEventArgs e)
        {
            _connect.Server("cfx.re/join/YOUID");
        }
    }
}
