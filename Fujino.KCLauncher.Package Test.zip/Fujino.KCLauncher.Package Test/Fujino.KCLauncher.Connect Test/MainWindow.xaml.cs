﻿using FujinoNs.Connect;
using System.Windows;

namespace Fujino.KCLauncher.Connect_Test
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        KCConnect _connect = new KCConnect();
        private void btn_joingameIP_Click(object sender, RoutedEventArgs e)
        {
            _connect.Server("127.0.0.1:30120");
        }

        private void btn_joingameJoinID_Click(object sender, RoutedEventArgs e)
        {
            _connect.Server("cfx.re/join/YOUID");
        }
    }
}
