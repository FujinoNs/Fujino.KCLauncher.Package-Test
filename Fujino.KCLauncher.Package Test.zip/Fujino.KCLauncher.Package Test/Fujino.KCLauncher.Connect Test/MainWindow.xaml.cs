﻿using Fujino.KCLauncher.Connect;
using System.Windows;

namespace Fujino.KCLauncher.Connect_Test
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        KC_Connection _Connection = new KC_Connection();
        private void btn_joingameIP_Click(object sender, RoutedEventArgs e)
        {
            _Connection.CMDConnectionFiveM("127.0.0.1:30120");
        }

        private void btn_joingameJoinID_Click(object sender, RoutedEventArgs e)
        {
            _Connection.CMDConnectionFiveM("cfx.re/join/YOUID");
        }

        private void btn_joingameIP_Path_Click(object sender, RoutedEventArgs e)
        {
            _Connection.ShellConnectionFiveM("127.0.0.1:30120", txt_fivemPath.Text);
        }

        private void btn_joingameJoinID_Path_Click(object sender, RoutedEventArgs e)
        {
            _Connection.ShellConnectionFiveM("cfx.re/join/YOUID", txt_fivemPath.Text);
        }

    }
}
