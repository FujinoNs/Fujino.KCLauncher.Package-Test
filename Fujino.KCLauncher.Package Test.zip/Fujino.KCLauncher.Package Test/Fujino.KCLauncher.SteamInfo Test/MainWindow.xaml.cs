﻿using FujinoNs.SteamInfo;
using System.Windows;

namespace Fujino.KCLauncher.SteamInfo_Test
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.SteamInfo();
        }

        KCSteamInfo _steamInfo = new KCSteamInfo();
        void SteamInfo()
        {
            lbl_steamname.Content = _steamInfo.SteamName();
            lbl_steamid.Content = _steamInfo.SteamID();
        }
    }
}
